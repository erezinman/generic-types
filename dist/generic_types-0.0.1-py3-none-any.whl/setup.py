from setuptools import setup

setup(
    name='generic-types',
    version='0.0.1',
    packages=[''],
    url='https://github.com/erezinman/generic-types',
    license='MIT License',
    author='Erez Zinman',
    author_email='erezinman.programmer@gmail.com',
    description='This is...'
)
